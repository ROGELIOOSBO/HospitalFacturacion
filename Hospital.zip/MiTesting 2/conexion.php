<?php
	
	$mysqli = new mysqli('localhost:8889', 'root', 'root', 'doctores');
	
	if($mysqli->connect_error){
		
		die('Error en la conexion' . $mysqli->connect_error);
		
	}
?>