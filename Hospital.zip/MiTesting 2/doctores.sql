CREATE DATABASE doctores;
USE doctores;
CREATE TABLE IF NOT EXISTS doctor(
 id int(11) NOT NULL AUTO_INCREMENT,
 nombre varchar(50) NOT NULL ,
 correo varchar(50) NOT NULL,
 telefono varchar(50) NOT NULL,
 universidad_egreso varchar(50) NOT NULL,
 especialidad varchar(5) NOT NULL,
 intereses varchar(50) NOT NULL,
 primary key(id));

